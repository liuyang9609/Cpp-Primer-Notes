#include "exercise14_7.h"

int main()
{
	String str("Hello World");
	std::cout << str << std::endl;
}